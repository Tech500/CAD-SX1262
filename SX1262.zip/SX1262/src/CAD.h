#ifndef CAD_H
#define CAD_H

#include <Arduino.h>
#include <SPI.h>
// #include "sx126x-board.h" // Commented out to prevent duplicate definitions
#include "sx1262_commands.h"

#endif