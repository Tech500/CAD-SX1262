// ============================================================
// SX1262 COMMANDS
// ============================================================

#define SX126X_CMD_SET_STANDBY        0x80
#define SX126X_CMD_SET_PACKET_TYPE    0x8A
#define SX126X_CMD_SET_RF_FREQUENCY   0x86
#define SX126X_CMD_SET_MOD_PARAMS     0x8B
#define SX126X_CMD_SET_PACKET_PARAMS  0x8C
#define SX126X_CMD_SET_DIO_IRQ        0x08
#define SX126X_CMD_CLEAR_IRQ          0x02
#define SX126X_CMD_GET_IRQ            0x12
#define SX126X_CMD_SET_CAD_PARAMS     0x88
#define SX126X_CMD_SET_CAD            0xC5
#define SX126X_CMD_SET_RX_DUTY_CYCLE  0x94
#define SX126X_CMD_WRITE_REGISTER      0x0D
#define SX126X_CMD_READ_REGISTER       0x1D
#define SX126X_CMD_SET_DIO2_AS_RF_SWITCH  0x9D

// ============================================================
// REGISTERS
// ============================================================
#define REG_XTAL_TRIM_A                0x0911
#define REG_XTAL_TRIM_B                0x0912
#define REG_RX_GAIN                    0x08AC

SPIClass radioSPI(FSPI);

// ============================================================
// SX1262 IRQ MASKS
// ============================================================

#define IRQ_RX_DONE             0x0002
#define IRQ_PREAMBLE_DETECTED   0x0004

#define IRQ_CAD_DONE            0x0080
#define IRQ_CAD_DETECTED        0x0100

#define IRQ_CAD_ALL             (IRQ_CAD_DONE | IRQ_CAD_DETECTED)

// ============================================================
// LoRa SETTINGS
// Must match known-good RadioLib transmitter.
// ============================================================

#define LORA_FREQ_HZ       915000000UL
#define LORA_SF            7
#define LORA_BW            7       // 125 kHz
#define LORA_CR            1       // 4/5
#define LORA_PREAMBLE      12

// OpCodes
#define SX126X_CMD_SET_REGULATOR_MODE 0x96



// ============================================================
// LOW-LEVEL SPI FUNCTIONS
// ============================================================

void sxWaitBusy() {   
  uint32_t start = millis();
  while (digitalRead(RADIO_BUSY_PIN) == HIGH) {
    if (millis() - start > 500) { // 500ms safety timeout
      Serial.println(F("[ERROR] SX1262 BUSY Timeout!"));
      break;
    }
    yield();
  }
}

inline void sxCommand(uint8_t opcode, const uint8_t *data, size_t len) {
  sxWaitBusy();
  digitalWrite(RADIO_CS_PIN, LOW);
  radioSPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
  radioSPI.transfer(opcode);
  for (size_t i = 0; i < len; i++) {
    radioSPI.transfer(data[i]);
  }
  radioSPI.endTransaction();
  digitalWrite(RADIO_CS_PIN, HIGH);
  sxWaitBusy();
}

inline void sxCommand(uint8_t opcode) {
  sxCommand(opcode, nullptr, 0);
}

inline void sxReadCommand(uint8_t opcode, uint8_t *data, size_t len) {
  sxWaitBusy();
  digitalWrite(RADIO_CS_PIN, LOW);
  radioSPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
  radioSPI.transfer(opcode);
  radioSPI.transfer(0x00); // Status dummy byte
  for (size_t i = 0; i < len; i++) {
    data[i] = radioSPI.transfer(0x00);
  }
  radioSPI.endTransaction();
  digitalWrite(RADIO_CS_PIN, HIGH);
}

inline void sxWriteRegister(uint16_t address, uint8_t value) {
  uint8_t data[3];
  data[0] = (address >> 8) & 0xFF;
  data[1] = address & 0xFF;
  data[2] = value;
  sxCommand(SX126X_CMD_WRITE_REGISTER, data, 3);
}


// ============================================================
// RESET
// ============================================================

void sxReset()
{
  Serial.println("SX1262 reset...");

  digitalWrite(RADIO_RST_PIN, LOW);
  delay(10);

  digitalWrite(RADIO_RST_PIN, HIGH);
  delay(20);

  sxWaitBusy();

  Serial.println("SX1262 reset complete.");
}

// ============================================================
// STANDBY
// ============================================================

void sxStandby()
{
  uint8_t data[] = {0x00};       // STDBY_RC

  sxCommand(
      SX126X_CMD_SET_STANDBY,
      data,
      1);
}

// ============================================================
// PACKET TYPE = LORA
// ============================================================

void sxSetPacketTypeLoRa()
{
  uint8_t data[] = {0x01};

  sxCommand(
      SX126X_CMD_SET_PACKET_TYPE,
      data,
      sizeof(data));
}

// ============================================================
// RF FREQUENCY
// ============================================================

inline void sxSetFrequency(uint32_t freqHz) {
  uint32_t steps = (uint32_t)((double)freqHz / (32000000.0 / 33554432.0));
  uint8_t data[4] = {
    (uint8_t)((steps >> 24) & 0xFF),
    (uint8_t)((steps >> 16) & 0xFF),
    (uint8_t)((steps >> 8) & 0xFF),
    (uint8_t)(steps & 0xFF)
  };
  sxCommand(SX126X_CMD_SET_RF_FREQUENCY, data, 4);
}

// ============================================================
// LoRa MODULATION PARAMETERS
// ============================================================

void sxSetLoRaModulation()
{
  uint8_t data[4];

  data[0] = LORA_SF;
  data[1] = 0x70;       // 125 kHz
  data[2] = LORA_CR;
  data[3] = 0x00;       // LDRO off

  sxCommand(
      SX126X_CMD_SET_MOD_PARAMS,
      data,
      4);
}

// ===================================
//  Antenna switch
// ===================================
inline void sxSetDio2AsRfSwitch() {
  uint8_t data[] = { 0x01 };
  sxCommand(SX126X_CMD_SET_DIO2_AS_RF_SWITCH, data, 1);
}

// ============================================================
// LoRa PACKET PARAMETERS
// ============================================================

void sxSetLoRaPacket()
{
  uint8_t data[6];

  data[0] = (LORA_PREAMBLE >> 8) & 0xFF;
  data[1] = LORA_PREAMBLE & 0xFF;

  data[2] = 0x00;       // Explicit header
  data[3] = 0xFF;       // Max payload
  data[4] = 0x01;       // CRC ON
  data[5] = 0x00;       // Normal IQ

  sxCommand(
      SX126X_CMD_SET_PACKET_PARAMS,
      data,
      6);
}

// ============================================================
// CAD PARAMETERS
// ============================================================

inline void sxSetCadParams() {
  uint8_t cadParams[7] = {
    0x03,  // 8 Symbols
    0x16,  // Peak threshold
    0x0A,  // Min threshold
    0x00,  // Exit Mode: CAD_ONLY
    0x00, 0x00, 0x00
  };
  sxCommand(SX126X_CMD_SET_CAD_PARAMS, cadParams, 7);
}

// ============================================================
// UNIFIED WOR / CAD IRQ ROUTING
// Maps both CAD_DETECTED and PREAMBLE_DETECTED to DIO1
// ============================================================
void sxConfigureWorIrq()
{
  uint8_t data[8];

  // Combine CAD_DETECTED (0x0100) and PREAMBLE_DETECTED (0x0004)
  // If defined in bitmask hex: 0x0104 (or 0x0196 to catch Header/RxDone too)
  uint16_t irqMask = IRQ_CAD_DETECTED | IRQ_PREAMBLE_DETECTED;

  // Global IRQ mask
  data[0] = (uint8_t)(irqMask >> 8);
  data[1] = (uint8_t)(irqMask & 0xFF);

  // DIO1 mask (Drives output to 74HC04 -> GPIO 16 wake pin)
  data[2] = (uint8_t)(irqMask >> 8);
  data[3] = (uint8_t)(irqMask & 0xFF);

  // DIO2
  data[4] = 0x00;
  data[5] = 0x00;

  // DIO3
  data[6] = 0x00;
  data[7] = 0x00;

  sxCommand(SX126X_CMD_SET_DIO_IRQ, data, 8);
}

// ============================================================
// CLEAR IRQ
// ============================================================

void sxClearIrq()
{
  uint8_t data[2] =
  {
    0xFF,
    0xFF
  };

  sxCommand(
      SX126X_CMD_CLEAR_IRQ,
      data,
      2);
}

// ============================================================
// READ IRQ
// ============================================================

uint16_t sxGetIrq()
{
  uint8_t data[2];

  sxReadCommand(
      SX126X_CMD_GET_IRQ,
      data,
      2);

  return
      ((uint16_t)data[0] << 8) |
      data[1];
}

// ============================================================
// START CAD
// ============================================================

void sxStartCad()
{
  Serial.println("Starting SX1262 CAD...");

  sxWaitBusy();

  digitalWrite(RADIO_CS_PIN, LOW);

  radioSPI.beginTransaction(
      SPISettings(8000000, MSBFIRST, SPI_MODE0));

  radioSPI.transfer(
      SX126X_CMD_SET_CAD);

  radioSPI.endTransaction();

  digitalWrite(RADIO_CS_PIN, HIGH);
}

// ============================================================
// SX1262 RX DUTY CYCLE / AUTONOMOUS WOR
//
// RX for rxPeriod
// SLEEP for sleepPeriod
// Automatically repeats.
//
// Timing unit = 15.625 us
//
// Both parameters are 24-bit values.
// ============================================================

inline void sxRXDutyCycle() {
  uint8_t dutyData[7] = {
    0x00, 0x08, 0x00,  // ~32 ms listening window
    0x00, 0x7D, 0x00,  // ~1000 ms sleep window
    0x02               // CAD Duty Cycle Mode 0x01
  };
  sxCommand(SX126X_CMD_SET_RX_DUTY_CYCLE, dutyData, 7);
}

